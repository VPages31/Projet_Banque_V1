#include <iostream>
#include <string>
using namespace std;
#include "banque.h"

int main()
{
	CLEAR;
	Banque B;
	B.Menu();
}