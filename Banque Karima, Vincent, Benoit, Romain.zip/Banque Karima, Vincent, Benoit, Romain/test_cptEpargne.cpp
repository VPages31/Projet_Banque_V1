#include <iostream>
#include <string>
using namespace std;
#include "cptEpargne.h"

main ()
{
	CLEAR;
	
	CptEpargne E("333333"); // Test constructeur avec parametres numCompte au minimum
	E.Menu();
	
	CLEAR;
}
