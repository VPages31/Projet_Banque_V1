#include <iostream>
#include <string>
using namespace std;
#include "compte.h"
#include "cptBloque.h"



main ()
{
	CLEAR;
	
	CptBloque B("111111");
	B.Menu();
	
	CLEAR;
}
