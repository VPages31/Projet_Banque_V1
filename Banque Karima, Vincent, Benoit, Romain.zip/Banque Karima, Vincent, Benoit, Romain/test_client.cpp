#include <iostream>
#include <string>
using namespace std;
#include "client.h"
#include "compte.h"

main ()
{
	CLEAR;
		Client C;
		C.Menu();
	CLEAR;
}
