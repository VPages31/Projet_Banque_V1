#include <iostream>
#include <string>
using namespace std;
#include "cptPEL.h"
main ()
{
	CLEAR;
	
	CptPEL P;
	P.Menu();
	
	CLEAR;
}
